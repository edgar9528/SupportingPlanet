package com.edgar_avc.supportingplanet.Ventanas.Administrador;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

import com.edgar_avc.supportingplanet.R;

public class EsperaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_espera);

        /*Toolbar toolbar = findViewById(R.id.toolbar);
        this.setSupportActionBar(toolbar);
        this.getSupportActionBar().setTitle("SupportingPlanet");
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(false);*/



    }

}
